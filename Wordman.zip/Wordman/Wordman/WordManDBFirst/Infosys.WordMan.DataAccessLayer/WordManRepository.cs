﻿using Infosys.WordMan.DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Infosys.WordMan.DataAccessLayer
{   
    public class WordManRepository
    {
       public static List<string> keyword = new List<string>()

       { "Birthday", "Christmas","Diwali","Dussehra","Farewell","Gandhi Jayanti","Holi","Independence Day","Joining Anniversary","New Year","Rakshabandhan","Republic Day"};
        DataAccessLayer.Models.WordManDBContext context;

        public WordManRepository(WordManDBContext con)
        {
            context = con;
        }
        public WordManRepository()
        {
            context = new DataAccessLayer.Models.WordManDBContext();
        }

        public List<Categories> GetCategories()
        {
            var categoriesList = new List<Categories>();
            try
            {
                categoriesList = (from category in context.Categories
                                  orderby category.CategoryId
                                  select category).ToList();

            }
            catch
            {
                categoriesList = null;
            }

            return categoriesList;
        }

        public List<Message> GetAllMessages()
        {
            var messageList = new List<Message>();
            try
            {
                messageList = (from msg in context.Message
                               orderby msg.MessageId
                               select msg).ToList();

            }
            catch
            {
                messageList = null;
            }

            return messageList;
        }

        public List<Message> GetMessageOnCategoryId(byte categoryId)
        {
            List<Message> lstmsgg = null;
            try
            {
                lstmsgg = context.Message.Where(p => p.CategoryId == categoryId).ToList();
            }
            catch (Exception ex)
            {
                lstmsgg = null;
            }
            return lstmsgg;
        }


        public bool AddCategory(string categoryName)
        {
            bool status = false;
            Categories category = new Categories();
            category.CategoryName = categoryName;
            try
            {
                context.Categories.Add(category);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool AddMessage(Message msg)
        {
            bool status = false;
            msg.MessageId = GetNextMessageId();
            try
            {
                context.Message.Add(msg);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool UpdateCategory(Categories cat)
        {
            bool status = false;
            Categories cat1 = context.Categories.Find(cat.CategoryId);
            try
            {
                if (cat1 != null)
                {
                    cat1.CategoryName = cat.CategoryName;
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool UpdateMessage(Message mess)
        {
            bool status = false;
            Message mess1 = context.Message.Find(mess.MessageId);
            try
            {
                if (mess1 != null)
                {
                    mess1.MessageDetails = mess.MessageDetails;
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool DeleteCategory(Categories cat)
        {
            Categories cat1 = null;
            bool status = false;
            try
            {
                cat1 = context.Categories.Find(cat.CategoryId);
                if (cat1 != null)
                {
                    context.Categories.Remove(cat1);
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        public bool DeleteMessage(Message mess)
        {
            Message mess1 = null;
            bool status = false;
            try
            {
                mess1 = context.Message.Find(mess.MessageId);
                if (mess1 != null)
                {
                    context.Message.Remove(mess1);
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        public List<Feedback> GetFeedBack()
        {
            var FeedBackList = new List<Feedback>();
            try
            {
                FeedBackList = (from feedback in context.Feedback
                                orderby feedback.FeedBackId
                                select feedback).ToList();

            }
            catch
            {
                FeedBackList = null;
            }

            return FeedBackList;
        }

        public byte? ValidateCredentials(string username, string password)
        {
            Users user = (from usr in context.Users where usr.UserName==username select usr).FirstOrDefault();
            byte? roleId = 0;
            if (user.UserPassword == password)
            {
                roleId = user.RoleId;
            }

            return roleId;
        }
        public bool RegisterUser(Users us)
        {
            try
            {
                Users userObj = new Users();
                userObj.EmailId = us.EmailId;
                userObj.UserPassword = us.UserPassword;
                userObj.Gender = us.Gender;
                userObj.DateOfBirth = us.DateOfBirth;
                userObj.Address = us.Address;
                userObj.RoleId = 2;
                userObj.CardNumber = us.CardNumber;
                userObj.StartDate = us.StartDate;
                userObj.EndDate = us.EndDate;
                context.Users.Add(userObj);

                context.SaveChanges();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool EditUserProfile(Users us)
        {
            Users us1 = context.Users.Find(us.UserId);
            bool status = false;
            try
            {
                if (us1 != null)
                {
                    us1.UserName = us.UserName;
                    us1.UserPassword = us.UserPassword;
                    us1.Gender = us.Gender;
                    us1.DateOfBirth = us.DateOfBirth;
                    us1.EmailId = us.EmailId;
                    us1.Address = us.Address;

                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }

            }
            catch (Exception e)
            {
                status = false;
            }
            return status;
        }



        public string GetNextMessageId()
        {
            string ans = (from msg in context.Message select msg.MessageId).Max();

            int finalans = Convert.ToInt32(ans.Substring(1)) + 1;
            string Id = "M" + Convert.ToString(finalans);
            return Id;
        }
        public string GetNextTemplateId()
        {
            string ans = (from msg in context.Templates select msg.TemplateId).Max();

            int finalans = Convert.ToInt32(ans.Substring(1)) + 1;
            string Id = "T" + Convert.ToString(finalans);
            return Id;
        }

        public bool SearchMessages(string msg)
        {
            msg = msg.Trim();
            byte categoryId;
            bool status = false;
            List<string> usercategory = new List<string>();
            string[] messages = msg.Split(" ");
            try
            {
                foreach (var item in keyword)
                {
                    foreach (var item1 in messages)
                    {
                        if (item1.ToLower().Contains(item.ToLower()))
                        {
                            usercategory.Add(item);
                            status = true;
                        }
                    }


                }

                foreach (var item in usercategory)
                {
                    categoryId = (from cat in context.Categories where cat.CategoryName == item select cat.CategoryId).First();
                    GetMessageOnCategoryId(categoryId);


                }



            }
            catch (Exception e)
            {
                status = false;
                throw;
            }
            return status;

            

        }

        public int GiveRating(Rating rat)
        {
            int ratid = (from rati in context.Rating select rati.RatingId).Max();
            int result = 0;

            try
            {
                if (ratid == 0)
                {
                    ratid = 1;
                }
                else
                {
                    ratid += 1;
                }
                rat.RatingId = ratid;
                Rating target = (from rating_obj in context.Rating
                                 where (rating_obj.MessageId == rat.MessageId &&
                                 rating_obj.UserId == rat.UserId)
                                 select rating_obj).FirstOrDefault();

                if (target == null)
                {
                    
                    result = AddRating(rat);
                    return result;
                }
                else
                {


                    result = EditRating(rat);
                    return result;

                }
            }

            catch
                {
                return -99;

            }

        }

        public int AddRating(Rating rat)
        {
           int status = 0;
           
            try
            {
                context.Rating.Add(rat);
                context.SaveChanges();
                status = 1;
            }
            catch (Exception)
            {
                status = 0;
            }
            return status;
        }

        public int EditRating(Rating rat)
        {
            int status = 0;
            Rating rat1 = context.Rating.Find(rat.RatingId);
            try
            {
                if (rat1 != null)
                {
                    rat1.RatingValue = rat.RatingValue;
                    context.SaveChanges();
                    status = 1;
                }
                else
                {
                    status = 0;
                }
            }
            catch (Exception)
            {
                status = 0;
            }
            return status;
        }

        public double? ShowRating(Rating rat)
        {
           double? rating = (from rat1 in context.Rating
                          orderby rat.RatingId
                          where rat1.UserId == rat.UserId
                          select rat.RatingValue).Average();

            return rating;



        }

    }
}
