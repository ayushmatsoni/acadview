﻿using System;
using System.Collections.Generic;

namespace Infosys.WordMan.DataAccessLayer.Models
{
    public partial class Users
    {
        public Users()
        {
            Feedback = new HashSet<Feedback>();
            Rating = new HashSet<Rating>();
        }

        public int UserId { get; set; }
        public string UserName { get; set; }
        public string UserPassword { get; set; }
        public byte? RoleId { get; set; }
        public string Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }
        public decimal? CardNumber { get; set; }
        public string EmailId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        public CardDetails CardNumberNavigation { get; set; }
        public Roles Role { get; set; }
        public ICollection<Feedback> Feedback { get; set; }
        public ICollection<Rating> Rating { get; set; }
    }
}
