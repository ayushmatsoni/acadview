﻿using System;
using System.Collections.Generic;

namespace Infosys.WordMan.DataAccessLayer.Models
{
    public partial class Message
    {
        public Message()
        {
            Rating = new HashSet<Rating>();
        }

        public string MessageId { get; set; }
        public string MessageDetails { get; set; }
        public byte? CategoryId { get; set; }
        public int? Download { get; set; }

        public Categories Category { get; set; }
        public ICollection<Rating> Rating { get; set; }
    }
}
