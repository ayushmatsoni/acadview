﻿using System;
using System.Collections.Generic;

namespace Infosys.WordMan.DataAccessLayer.Models
{
    public partial class Feedback
    {
        public int? UserId { get; set; }
        public string FeedBack1 { get; set; }
        public int FeedBackId { get; set; }

        public Users User { get; set; }
    }
}
