﻿using System;
using Infosys.WordMan.DataAccessLayer;
namespace Infosys.WordMan.ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            
            WordManRepository abc = new WordManRepository();
            //string a = abc.GetNextTemplateId();
            //Console.WriteLine(a);
            //foreach (var item in WordManRepository.keyword)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine();

            string x = "wishing u happydiwaliiiiiii";
            Console.WriteLine(abc.SearchMessages(x));
        }
    }
}
