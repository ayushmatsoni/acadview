﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Wordman.Models
{
    public class Message
    {
        public string MessageId { get; set; }
        public string MessageDetails { get; set; }
        public byte? CategoryId { get; set; }
        public int? Download { get; set; }
    }
}
