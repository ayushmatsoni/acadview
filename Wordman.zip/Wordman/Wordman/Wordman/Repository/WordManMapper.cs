﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Infosys.WordMan.DataAccessLayer.Models;
namespace Wordman.Repository
{
    public class WordmanMapper: Profile
    {
        public WordmanMapper()
        {
            CreateMap<Categories, Models.Categories>();
            CreateMap<Message,Models.Message>();
            CreateMap<Models.Categories,Categories>();
            CreateMap<Message, Models.Message>();
        }
    }
}
