﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Wordman.Models
{
    public class Message
    {
        public string MessageId { get; set; }
        [StringLength(maximumLength: 500)]
        [Required(ErrorMessage = "Message must not be empty")]
        public string MessageDetails { get; set; }
        [Required]
        [Range(1,1000, ErrorMessage = "id Must be greater than 0")]
        public byte? CategoryId { get; set; }
        public int? Download { get; set; }
        [Required]
        public string Relationship { get; set; }
        public double Rate { get; set; }
        public int? RatingCount { get; set; }
    }
}
