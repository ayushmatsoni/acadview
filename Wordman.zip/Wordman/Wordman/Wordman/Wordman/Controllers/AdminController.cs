﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Infosys.WordMan.DataAccessLayer;
using Infosys.WordMan.DataAccessLayer.Models;
using AutoMapper;
using Microsoft.AspNetCore.Http;

namespace Wordman.Controllers
{
    public class AdminController : Controller
    {
        private readonly IMapper _mapper;
        private readonly WordManRepository _repObj;
        public AdminController(WordManRepository repObj, IMapper mapper)
        {
            _repObj = repObj;
            _mapper = mapper;
        }
        public IActionResult AdminHome()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        public IActionResult AddCategory()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        public IActionResult SaveAddedCategory(Models.Categories cat)
        {

            bool status = false;
            if (ModelState.IsValid)
            {
                var name = cat.CategoryName;
                try
                {
                    status = _repObj.AddCategory(name);
                    if (status)
                        return RedirectToAction("ViewCategory");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("AddCategory", cat);
        }
        public IActionResult ViewMessages(Models.Categories cat)
        {
            byte id = cat.CategoryId;
            var msglst = _repObj.GetMessageOnCategoryId(id);
            List<Models.Message> finalMsgList = new List<Models.Message>();
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            foreach (var product in msglst)
            {
                finalMsgList.Add(_mapper.Map<Models.Message>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(finalMsgList);

        }

        public IActionResult ViewCategory()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(lstModelProducts);
        }
        public IActionResult DeleteCateGory(Models.Categories cat)
        {
            bool status = false;
            try
            {
                status = _repObj.DeleteCategory(_mapper.Map<Categories>(cat));
                if (status)
                    return RedirectToAction("ViewCategory");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }



        }
        public IActionResult SearchMessages(IFormCollection frm)
        {

            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            string searchstring = frm["search"];
            List<Models.Message> finalMsg = new List<Models.Message>();
            List<Message> msg = _repObj.SearchMessages(searchstring);
            foreach (var item in msg)
            {
                finalMsg.Add(_mapper.Map<Models.Message>(item));
            }
            return View(finalMsg);
        }
        public IActionResult EditMessage(Models.Message msg)
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(msg);
        }

        public IActionResult EditCategory(Models.Categories cat)
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(cat);
        }

        public IActionResult SaveEditCategory(Models.Categories cat)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                var name = cat.CategoryName;
                try
                {
                    status = _repObj.UpdateCategory(_mapper.Map<Categories>(cat));
                    if (status)
                        return RedirectToAction("ViewCategory");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("EditCategory", cat);

        }

        public IActionResult EditMessages(Models.Message msg)
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(msg);
        }
        public IActionResult SaveEditMessages(Models.Message msg)
        {

            bool status = false;
            if (ModelState.IsValid)
            {

                try
                {
                    status = _repObj.UpdateMessage(_mapper.Map<Message>(msg));
                    if (status)
                        return RedirectToAction("ViewCategory");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }


            return RedirectToAction("EditMessages", msg);
        }
        public IActionResult DeleteMessages(Models.Message msg)
        {
            bool status = false;
            try
            {
                status = _repObj.DeleteMessage(_mapper.Map<Message>(msg));
                if (status)
                    return RedirectToAction("ViewCategory");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }



        }

        public IActionResult AddMessages()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();

        }
        public IActionResult SaveAddMessages(Models.Message msg)
        {
            bool status = false;
            try
            {
                status = _repObj.AddMessage(_mapper.Map<Message>(msg));
                if (status)
                    return RedirectToAction("ViewCategory");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }


        }
        public IActionResult ViewFeedBack()
        {
           
            var fb = _repObj.GetFeedBack();
            List<Models.Feedback> finalMsgList = new List<Models.Feedback>();
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            foreach (var product in fb)
            {
                finalMsgList.Add(_mapper.Map<Models.Feedback>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(finalMsgList);
        }
    }
}