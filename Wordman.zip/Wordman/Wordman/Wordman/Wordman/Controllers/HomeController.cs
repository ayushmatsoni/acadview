﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Mvc;
using Wordman.Models;
using Infosys.WordMan.DataAccessLayer;
using Infosys.WordMan.DataAccessLayer.Models;
using Microsoft.AspNetCore.Http;
using AutoMapper;

namespace Wordman.Controllers
{
    public class HomeController : Controller
    {
        private readonly IMapper _mapper;
        private readonly  WordManRepository  _repObj;
        public HomeController(WordManRepository repObj,IMapper mapper)
        {
            _mapper = mapper;
            _repObj = repObj;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Checkrole(IFormCollection frm)
        
        {
           
                string userId = frm["uname"];
                string password = frm["psw"];
                string checkbox = frm["remember"];
                if (checkbox == "on")
                {
                    CookieOptions option = new CookieOptions();
                    option.Expires = DateTime.Now.AddDays(2);
                    Response.Cookies.Append("Username", userId, option);
                    Response.Cookies.Append("Password", password, option);
                }
            try
            {
                byte? roleId = _repObj.ValidateCredentials(userId, password);
                if (roleId == 1)
                {
                    HttpContext.Session.SetString("usr", userId);
                    return RedirectToAction("AdminHome", "Admin");
                }
                else if (roleId == 2)
                {
                    HttpContext.Session.SetString("usr", userId);
                    return RedirectToAction("UserHome", "User");
                }
                return View("ErrorLogin");
            }
            catch (Exception e)
            {
                return View("ErrorLogin");
            }
        }
           

        
        

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("usr"); ;
            return RedirectToAction("UserHome", "User");
        }
        public IActionResult About()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        public IActionResult Contact()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        public IActionResult FeedBack()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        public IActionResult RegisterUser()
        {
            return View();
        }
        public IActionResult SaveRegisterUser(Models.Users usr)
        {
            bool status = false;
          //  if (ModelState.IsValid)
          //  {

                try
                {
                    status = _repObj.RegisterUser(_mapper.Map<Infosys.WordMan.DataAccessLayer.Models.Users>(usr));
                    if (status)
                        return RedirectToAction("UserHome", "User");
                    else
                        return View("ErrorRegister");
                }
                catch (Exception)
                {
                    return View("ErrorRegister");
                }
            //}
            //else
            //    return View();

        }
        public IActionResult SaveFeedBack(Models.Feedback fb)
        {
            bool status = false;
            try
            {
               status = _repObj.AddFeedBack(_mapper.Map<FeedBack>(fb));
                if (status)
                    return RedirectToAction("FeedBack");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }
           
        }

        [HttpPost]
        public JsonResult IsAlreadySigned(string username)
        {

            return Json(_repObj.IsUserAvailable(username));

        }
        public void getratings(IFormCollection frm)
        {
            string userId = frm["ratings"];
            

        }
        [HttpPost]
        public JsonResult ValidateDate(DateTime DateOfBirth)
        {
           
          bool  status = false;
            if (DateOfBirth.Date <DateTime.Now.Date)
                status= true;
            return Json(status);

        }

    }
}
