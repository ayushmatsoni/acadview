﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Infosys.WordMan.DataAccessLayer;
using Infosys.WordMan.DataAccessLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Wordman.Controllers
{
    public class UserController : Controller
    {
        private readonly IMapper _mapper;
        private readonly WordManRepository _repObj;
        public UserController(WordManRepository repObj, IMapper mapper)
        {
            _repObj = repObj;
            _mapper = mapper;
        }
        public IActionResult UserHome()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }

        public IActionResult ViewMessages(Models.Categories cat)
        {
            ViewBag.CatName = cat.CategoryName;
            byte id = cat.CategoryId;
            var msglst = _repObj.GetMessageOnCategoryId(id);
            List<Models.Message> finalMsgList = new List<Models.Message>();
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            foreach (var product in msglst)
            {
                finalMsgList.Add(_mapper.Map<Models.Message>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(finalMsgList);

        }

        public IActionResult ViewCategory()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(lstModelProducts);
        }
        public IActionResult DeleteCateGory(Models.Categories cat)
        {
            bool status = false;
            try
            {
                status = _repObj.DeleteCategory(_mapper.Map<Categories>(cat));
                if (status)
                    return RedirectToAction("ViewCategory");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }



        }
        public IActionResult SearchMessages(IFormCollection frm)
        {

            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            string searchstring = frm["search"];
            List<Models.Message> finalMsg = new List<Models.Message>();
            List<Message> msg = _repObj.SearchMessages(searchstring);
            foreach (var item in msg)
            {
                finalMsg.Add(_mapper.Map<Models.Message>(item));
            }
            return View(finalMsg);
        }

        public IActionResult GetTopRatedMessage()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;


            var lsttoprated = _repObj.TopRatedMessages();
            List<Models.Message> lstModelProduct = new List<Models.Message>();
            foreach (var product in lsttoprated)
            {
                lstModelProduct.Add(_mapper.Map<Models.Message>(product));
            }
            return View(lstModelProduct);

        }



        public IActionResult EditMessage(Models.Message msg)
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(msg);
        }
        public IActionResult getrating(IFormCollection frm)

        {
            string rating = frm["ratings"];
            Models.Message msg = new Models.Message();
            msg.CategoryId = Convert.ToByte(frm["cid"]);
            msg.Download = Convert.ToInt32(frm["download"]);
            msg.MessageDetails = frm["md"];
            msg.Relationship = frm["relationship"];
            msg.MessageId = frm["mid"];
            msg.Rate = Convert.ToDouble(frm["rate"]);

            Models.Rating rat = new Models.Rating();
            rat.MessageId = frm["mid"];
            rat.UserId = _repObj.GetUserId(HttpContext.Session.GetString("usr"));
            rat.RatingValue = Convert.ToInt32(rating);
           var s=  _repObj.GiveRating(_mapper.Map<Rating>(rat));
            _repObj.CalculateRating(_mapper.Map<Message>(msg));
            if (s==1)
            {
                return RedirectToAction("EditMessage", msg);
            }
            else
            {
                return View("Error");
            }
            }
        public IActionResult IncrementDownload(IFormCollection frm)

        {

            Models.Message msg = new Models.Message();
            msg.CategoryId = Convert.ToByte(frm["cid"]);
            msg.Download = Convert.ToInt32(frm["download"]);
            msg.MessageDetails = frm["md"];
            msg.Relationship = frm["relationship"];
            msg.MessageId = frm["mid"];
            msg.Rate = Convert.ToDouble(frm["rate"]);
            msg.RatingCount = Convert.ToInt32(frm["ratingcount"]);
            var s = _repObj.IncDownload(_mapper.Map<Message>(msg));
            if (s)
            {
                return RedirectToAction("EditMessage", msg);
            }
            else
            {
                return View("Error");
            }
        }
    }
}