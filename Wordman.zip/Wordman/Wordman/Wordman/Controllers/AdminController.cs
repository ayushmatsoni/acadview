﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Infosys.WordMan.DataAccessLayer;
using Infosys.WordMan.DataAccessLayer.Models;
using AutoMapper;

namespace Wordman.Controllers
{
    public class AdminController : Controller
    {
        private readonly IMapper _mapper;
        private readonly WordManRepository _repObj;
        public AdminController(WordManRepository repObj, IMapper mapper)
        {
            _repObj = repObj;
            _mapper = mapper;
        }
        public IActionResult AdminHome()
        {
            return View();
        }
        public IActionResult AddCategory()
        {
            return View();
        }
        public IActionResult SaveAddedCategory(Models.Categories cat)
        {

            bool status = false;
            if (ModelState.IsValid)
            {
                var name = cat.CategoryName;
                try
                {
                    status = _repObj.AddCategory(name);
                    if (status)
                        return RedirectToAction("ViewCategory");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("AddCategory",cat);
        }
        public IActionResult ViewMessages(Models.Categories cat)
        {
            byte id = cat.CategoryId;
            var msglst = _repObj.GetMessageOnCategoryId(id);
            List<Models.Message> finalMsgList = new List<Models.Message>();
            foreach (var product in msglst)
            {
                finalMsgList.Add(_mapper.Map<Models.Message>(product));
            }
            return View(finalMsgList);
            
        }
       
        public IActionResult ViewCategory()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            return View(lstModelProducts);
        }
        public IActionResult DeleteCateGory(Models.Categories cat)
        {
            bool status = false;
            try
            {
                status = _repObj.DeleteCategory(_mapper.Map<Categories>(cat));
                if (status)
                    return RedirectToAction("ViewCategory");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }

           
            
        }
        public IActionResult EditMessage(Models.Message msg)
        {

            return View(msg);
        }
    }
}