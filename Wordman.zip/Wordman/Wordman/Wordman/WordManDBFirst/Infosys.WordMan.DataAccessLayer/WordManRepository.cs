﻿using Infosys.WordMan.DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Infosys.WordMan.DataAccessLayer
{
    public class WordManRepository
    {
        DataAccessLayer.Models.WordManDBContext context;
        public static List<string> keyword = new List<string>();
        public static List<string> keyword1 = new List<string>();

        //    { "Birthday", "Christmas","Diwali","Dussehra","Farewell","Gandhi Jayanti","Holi","Independence Day","Joining Anniversary","New Year","Rakshabandhan","Republic Day"};


        public static List<string> relationships = new List<string>();

       //{ "Brother","Father","Mother","Sister","Son","Daughter","Uncle","Aunty","Friend","Colleague",
       //     "Girlfriend","BoyFriend","GrandFather","GrandMother","Nephew","Neice","Cousin","Husband","Wife","general"};


    

    public WordManRepository(WordManDBContext con)
        {
            context = con;
        }
        public WordManRepository()
        {
            context = new DataAccessLayer.Models.WordManDBContext();
        }

        public List<Categories> GetCategories()
        {
            var categoriesList = new List<Categories>();
            try
            {
                categoriesList = (from category in context.Categories
                                  orderby category.CategoryId
                                  select category).ToList();

            }
            catch
            {
                categoriesList = null;
            }

            return categoriesList;
        }

        public List<string> GetCategoryNames()
        {
            var keyword = (from category in context.Categories
                           orderby category.CategoryId
                           select category.CategoryName).ToList();
            return keyword;
        }

        public List<string> GetRelationships()
        {
            var relationships = (from msgs in context.Message
                           orderby msgs.MessageId
                           select msgs.Relationship).ToList();
            return relationships;
        }

        

        public List<Message> GetAllMessages()
        {
            var messageList = new List<Message>();
            try
            {
                messageList = (from msg in context.Message
                               orderby msg.MessageId
                               select msg).ToList();

            }
            catch
            {
                messageList = null;
            }

            return messageList;
        }

        public List<Message> GetMessageOnCategoryId(byte categoryId)
        {
            List<Message> lstmsgg = null;
            try
            {
                lstmsgg = context.Message.Where(p => p.CategoryId == categoryId).ToList();
            }
            catch (Exception ex)
            {
                lstmsgg = null;
            }
            return lstmsgg;
        }


        public bool AddCategory(string categoryName)
        {
            bool status = false;
            Categories category = new Categories();
            category.CategoryName = categoryName;
            try
            {
                context.Categories.Add(category);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool AddMessage(Message msg)
        {
            bool status = false;
            msg.MessageId = GetNextMessageId();
            try
            {
                context.Message.Add(msg);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool UpdateCategory(Categories cat)
        {
            bool status = false;
            Categories cat1 = context.Categories.Find(cat.CategoryId);
            try
            {
                if (cat1 != null)
                {
                    cat1.CategoryName = cat.CategoryName;
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool UpdateMessage(Message mess)
        {
            bool status = false;
            Message mess1 = context.Message.Find(mess.MessageId);
            try
            {
                if (mess1 != null)
                {
                    mess1.MessageDetails = mess.MessageDetails;
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool DeleteCategory(Categories cat)
        {
            Categories cat1 = null;
            bool status = false;
            try
            {
                cat1 = context.Categories.Find(cat.CategoryId);
                if (cat1 != null)
                {
                    context.Categories.Remove(cat1);
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        public bool DeleteMessage(Message mess)
        {
            Message mess1 = null;
            bool status = false;
            try
            {
                mess1 = context.Message.Find(mess.MessageId);
                if (mess1 != null)
                {
                    context.Message.Remove(mess1);
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        public bool AddFeedBack(FeedBack fb)
        {
            bool status = false;
            try
            {
                context.FeedBack.Add(fb);
                context.SaveChanges();
                status = true;
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;

        }
        public List<FeedBack> GetFeedBack()
        {
            var FeedBackList = new List<FeedBack>();
            try
            {
                FeedBackList = (from feedback in context.FeedBack
                                orderby feedback.FeedBackId
                                select feedback).ToList();

            }
            catch
            {
                FeedBackList = null;
            }

            return FeedBackList;
        }

        public byte? ValidateCredentials(string username, string password)
        {
            Users user = (from usr in context.Users where usr.UserName == username select usr).FirstOrDefault();
            byte? roleId = 0;
            if (user.UserPassword == password)
            {
                roleId = user.RoleId;
            }

            return roleId;
        }
        public bool RegisterUser(Users us)
        {
            try
            {
                //Users userObj = new Users();
                //userObj.EmailId = us.EmailId;
                //userObj.UserPassword = us.UserPassword;
                //userObj.Gender = us.Gender;
                //userObj.DateOfBirth = us.DateOfBirth;
                //userObj.Address = us.Address;
                us.RoleId = 2;
                //userObj.CardNumber = us.CardNumber;
                //userObj.StartDate = us.StartDate;
                //userObj.EndDate = us.EndDate;
                context.Users.Add(us);

                context.SaveChanges();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool EditUserProfile(Users us)
        {
            Users us1 = context.Users.Find(us.UserId);
            bool status = false;
            try
            {
                if (us1 != null)
                {
                    us1.UserName = us.UserName;
                    us1.UserPassword = us.UserPassword;
                    us1.Gender = us.Gender;
                    us1.DateOfBirth = us.DateOfBirth;
                    us1.EmailId = us.EmailId;
                    us1.Address = us.Address;

                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }

            }
            catch (Exception e)
            {
                status = false;
            }
            return status;
        }



        public string GetNextMessageId()
        {
            string ans = (from msg in context.Message select msg.MessageId).Max();

            int finalans = Convert.ToInt32(ans.Substring(1)) + 1;
            string Id = "M" + Convert.ToString(finalans);
            return Id;
        }
        public string GetNextTemplateId()
        {
            string ans = (from msg in context.Templates select msg.TemplateId).Max();

            int finalans = Convert.ToInt32(ans.Substring(1)) + 1;
            string Id = "T" + Convert.ToString(finalans);
            return Id;
        }
        List<string> relationship = new List<string>();


        public List<Message> SearchMessages(string msg)
        {
            string a = "";
            List<string> keyword_removed = new List<String>();
            List<string> keyword_added = new List<String>();
            keyword = GetCategoryNames();
            relationship = GetRelationships();

            string temp = "";
            temp = msg;
            if (msg.ToLower().Contains("dad"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("dad"))
                        arr[i] = "Father";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();

            }
            else if (msg.ToLower().Contains("papa"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("papa"))
                        arr[i] = "Father";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("daddy"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("daddy"))
                        arr[i] = "Father";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }


            temp = msg;
            if (msg.ToLower().Contains("mom"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("mom"))
                        arr[i] = "Mother";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("mum"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("mum"))
                        arr[i] = "Mother";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("mummy"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("mummy"))
                        arr[i] = "Mother";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("maa"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("maa"))
                        arr[i] = "Mother";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("mumma"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("mumma"))
                        arr[i] = "Mother";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }



            temp = msg;
            if (msg.ToLower().Contains("sis"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("sis"))
                        arr[i] = "Sister";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            //else if (msg.ToLower().Contains("di"))
            //{
            //    msg = "";
            //    msg += temp.Replace("di", "sister");
            //}
            else if (msg.ToLower().Contains("didi"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("didi"))
                        arr[i] = "Sister";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }

            temp = msg;
            if (msg.ToLower().Contains("bro"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("bro"))
                        arr[i] = "Brother";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }

            else if (msg.ToLower().Contains("bhaiya"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("bro"))
                        arr[i] = "Brother";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("bhai"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("bro"))
                        arr[i] = "Brother";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }

            //colleague
            temp = msg;
            if (msg.ToLower().Contains("coworker"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("coworker"))
                        arr[i] = "colleague";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("teammate"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("teammate"))
                        arr[i] = "colleague";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("partner"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("partner"))
                        arr[i] = "colleague";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }


            temp = msg;
            if (msg.ToLower().Contains("buddy"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("buddy"))
                        arr[i] = "friend";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("bestfriend"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("bestfriend"))
                        arr[i] = "friend";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("mate"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("mate"))
                        arr[i] = "friend";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }


            temp = msg;
            if (msg.ToLower().Contains("husband"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("husband"))
                        arr[i] = "Spouse";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("wife"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("wife"))
                        arr[i] = "Spouse";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("soulmate"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("soulmate"))
                        arr[i] = "Spouse";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("betterhalf"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("betterhalf"))
                        arr[i] = "Spouse";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("love"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("love"))
                        arr[i] = "Spouse";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }
            else if (msg.ToLower().Contains("honey"))
            {
                string[] arr = msg.Split(" ");

                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].ToLower().Contains("honey"))
                        arr[i] = "Spouse";
                }
                msg = "";
                foreach (var item in arr)
                {

                    msg += item + " ";
                }
                msg = msg.Trim();
            }






            foreach (var item in keyword)
            {
                if (item.Contains(" "))
                {
                    keyword_removed.Add(item);
                    keyword_added.Add(item.Split(" ")[0]);
                }
            }
            foreach (var item in keyword_removed)
            {
                if (keyword.Contains(item))
                    keyword.Remove(item);
            }

            foreach (var item in keyword_added)
            {
                if (!keyword.Contains(item))
                    keyword.Add(item);
            }


            msg = msg.Trim();
            byte categoryId;
            string relation;

            bool status = false;
            List<string> usercategory = new List<string>();
            List<string> userrelationship = new List<string>();

            List<Message> finalList = new List<Message>();
            string[] messages = msg.Split(" ");
            try
            {
                foreach (var item in keyword)
                {
                    foreach (var item1 in messages)
                    {
                        if (item.ToLower().Contains(item1.ToLower()))
                        {
                            //if (!usercategory.Contains(item))
                            //{ usercategory.Add(item); }
                            //status = true; break;

                            if (item1.ToLower().Contains(item.ToLower()))
                            {
                                if (!usercategory.Contains(item.ToLower()))
                                { usercategory.Add(item); }
                                status = true; break;
                            }
                        }
                        //if (item1.ToLower().Contains(item.ToLower()))
                        //{
                        //    if (!usercategory.Contains(item))
                        //    { usercategory.Add(item); }
                        //    status = true; break;
                        //}
                    }


                }

                foreach (var item in relationship)
                {
                    foreach (var item1 in messages)
                    {
                        //if (item.ToLower().Contains(item1.ToLower()))
                        //{
                        //    if (!userrelationship.Contains(item))
                        //    {
                        //        userrelationship.Add(item);
                        //    }
                        //    status = true; break;
                        //}
                        if (item1.ToLower().Contains(item.ToLower()))
                        {
                            if (!userrelationship.Contains(item.ToLower()))
                            {
                                userrelationship.Add(item);
                            }
                            status = true; break;
                        }
                    }


                }
                List<Message> listMessage = new List<Message>();

                if (usercategory.Count != 0)
                {

                    foreach (var item in usercategory)
                    {
                        if (userrelationship.Count != 0)
                        {
                            foreach (var item1 in userrelationship)
                            {
                                var msgobj = (from obj in context.Message
                                              join c in context.Categories on obj.CategoryId equals c.CategoryId
                                              where c.CategoryName.ToLower().Contains(item.ToLower()) && obj.Relationship.ToLower() == item1.ToLower()
                                              orderby obj.MessageId
                                              select
                                             obj).Distinct()
                                                      .ToList();

                                if (msgobj.Count == 0)
                                {

                                    var msgobj1 = (from obj in context.Message
                                                   join c in context.Categories on obj.CategoryId equals c.CategoryId
                                                   where c.CategoryName.ToLower().Contains(item.ToLower())
                                                   orderby obj.MessageId
                                                   select
                                                  obj).Distinct()
                                                      .ToList();
                                    listMessage.AddRange(msgobj1);

                                }
                                else
                                {
                                    listMessage.AddRange(msgobj);
                                }
                            }
                        }


                        else
                        {
                            var msgobj = (from obj in context.Message
                                          join c in context.Categories on obj.CategoryId equals c.CategoryId
                                          where c.CategoryName.ToLower().Contains(item.ToLower())
                                          orderby obj.MessageId
                                          select
                                         obj).Distinct()
                                                  .ToList();
                            listMessage.AddRange(msgobj);

                        }
                    }







                }
                else
                {
                    foreach (var item1 in userrelationship)
                    {
                        var msgobj = (from obj in context.Message

                                      where obj.Relationship.ToLower() == item1.ToLower()
                                      orderby obj.MessageId
                                      select
                                     obj).Distinct()
                                              .ToList();
                        listMessage.AddRange(msgobj);

                    }
                }
                return listMessage;
            }
            catch (Exception e)
            {
                status = false;
                throw;
            }




        }

        public int GiveRating(Rating rat)
        {
              int result = 0;

            try
            {
             
                Rating target = (from rating_obj in context.Rating
                                 where (rating_obj.MessageId == rat.MessageId &&
                                 rating_obj.UserId == rat.UserId)
                                 select rating_obj).FirstOrDefault();

                if (target == null)
                {   
                    
                    result = AddRating(rat);
                    return result;
                }
                else
                {


                    result = EditRating(rat);
                    return result;

                }
            }

            catch
            {
                return -99;

            }

        }

        public int AddRating(Rating rat)
        {
            int status = 0;

            try
            {
                context.Rating.Add(rat);
                context.SaveChanges();
                status = 1;
            }
            catch (Exception)
            {
                status = 0;
            }
            return status;
        }

        public int EditRating(Rating rat)
        {
            int status = 0;
            Rating rat1 = (from rating_obj in context.Rating
                           where (rating_obj.MessageId == rat.MessageId &&
                           rating_obj.UserId == rat.UserId)
                           select rating_obj).FirstOrDefault();
            try
            {
                if (rat1 != null)
                {
                    rat1.RatingValue = rat.RatingValue;
                    context.SaveChanges();
                    status = 1;
                }
                else
                {
                    status = 0;
                }
            }
            catch (Exception)
            {
                status = 0;
            }
            return status;
        }

        public double? ShowRating(Rating rat)
        {
            double? rating = (from rat1 in context.Rating
                              orderby rat.RatingId
                              where rat1.UserId == rat.UserId
                              select rat.RatingValue).Average();

            return rating;



        }
        public List<Message> TopRatedMessages()
        {
            var list1= (from msg in context.Message
                        orderby msg.Rate descending
                        
                        select msg).Take(10).ToList();

            return list1;

        }


        public bool IsUserAvailable(string username)
        {
            var d = (from u in context.Users where u.UserName == username select u.UserName).FirstOrDefault();

            if(d!=null)
            {
                return false;
            }
            else { return  true; }
        }
        public int GetUserId(string username)
        {
            int usid = (from us in context.Users where us.UserName == username select us.UserId).FirstOrDefault();
            return usid;
        }
        public bool CalculateRating(Message msg)
        {
            double? rate= (from rating in context.Rating where rating.MessageId == msg.MessageId select rating.RatingValue).Average();
            int? ratingcount= (from rating in context.Rating where rating.MessageId == msg.MessageId select rating.UserId).Count();
            if (rate!=null)

            {
                msg.RatingCount = ratingcount;
                msg.Rate = rate;
                UpdateMessageRating(msg);
            }
            return false;


        }
        public bool UpdateMessageRating(Message mess)
        {
            bool status = false;
            Message mess1 = context.Message.Find(mess.MessageId);
            try
            {
                if (mess1 != null)
                {
                    mess1.RatingCount = mess.RatingCount;
                    mess1.Rate = mess.Rate;
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        public bool IncDownload(Message msg)
        {
            bool status = false;
            Message mess1 = context.Message.Find(msg.MessageId);

            try
            {
                if (mess1 != null)
                {
                    mess1.Download = mess1.Download + 1;
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

    }
}
