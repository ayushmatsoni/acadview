﻿using System;
using System.Collections.Generic;

namespace Infosys.WordMan.DataAccessLayer.Models
{
    public partial class Rating
    {
        public int RatingId { get; set; }
        public int? RatingValue { get; set; }
        public string MessageId { get; set; }
        public int UserId { get; set; }

        public Message Message { get; set; }
        public Users User { get; set; }
    }
}
