﻿using System;
using System.Collections.Generic;

namespace Infosys.WordMan.DataAccessLayer.Models
{
    public partial class Templates
    {
        public string TemplateId { get; set; }
        public byte? CategoryId { get; set; }
        public byte[] Template { get; set; }

        public Categories Category { get; set; }
    }
}
